
This application will install USB com port driver for MediTek device whose ID is:

Vid_0e8d&Pid_0013&MI_02


Supported OS:
	Windows XP (32/64)
	Windows Vist (32/64)
	Windows 7 (32/64)

The application user must have the administrator privilege to run.

Running "InstallDriver.exe" will do the installation. Running "installdrv64.exe" does not make sense.

Notes:
1. The folder structure must not be changed.
2. Running InstallDriver with command "-a" will install the driver silently (without GUI). And remove driver command is "-u". "-au" or "-ua" will remove driver silently.
